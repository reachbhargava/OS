mknod -m 222 /dev/fifo c 240 0
