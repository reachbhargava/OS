rmmod producer
rmmod consumer
rmmod queue