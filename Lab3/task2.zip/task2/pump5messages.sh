echo -n "0,1234567891,Message 1 - Echo 1 " > /dev/fifo
echo -n "0,2323423423,Message 2 - Echo 2 " > /dev/fifo
echo -n "0,1234567891,Message 3 - Echo 3 " > /dev/fifo
echo -n "0,1234567891,Message 4 - Echo 4 " > /dev/fifo
echo -n "0,2323423423,Message 5 - Echo 5 " > /dev/fifo